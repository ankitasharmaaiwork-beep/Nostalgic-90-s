import Link from "next/link";
import ThemeSongPlayer from "../../components/ThemeSongPlayer";
import ImageGrid from "../../components/ImageGrid";

const ACCENT = "#f4a742";

// Poster image lives in /public/images/pokemon
const IMAGES = [
  { src: "/images/pokemon/pokemon-poster.jpg", alt: "Pokémon show poster" },
];

// Official Pokémon theme song
const VIDEO_ID = "KIKjB33zaSk";

export default function PokemonPage() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <Link href="/" className="font-mono text-xs uppercase tracking-widest text-faint hover:text-cream">
        ← Back
      </Link>

      <header className="mt-6 mb-10">
        <span
          className="rounded-sm border px-2 py-1 font-mono text-[11px] uppercase tracking-widest"
          style={{ color: ACCENT, borderColor: ACCENT + "66" }}
        >
          1997
        </span>
        <h1 className="mt-4 font-display text-xl leading-[1.8] text-cream">
          Pokémon
        </h1>
        <p className="mt-2 italic" style={{ color: ACCENT }}>
          &ldquo;Gotta catch 'em all.&rdquo;
        </p>
        <p className="mt-3 max-w-xl text-muted">
          Ash, Pikachu, and a Pokédex with 150 slots to fill. The theme song
          plays automatically below — tap for sound.
        </p>
      </header>

      <section className="mb-12">
        <ThemeSongPlayer
          videoId={VIDEO_ID}
          title="Pokémon"
          accent={ACCENT}
          searchHint="Pokémon Theme Song official Pokémon YouTube channel"
        />
      </section>

      <section>
        <h2 className="mb-4 font-mono text-xs uppercase tracking-widest text-faint">
          Gallery
        </h2>
        <ImageGrid images={IMAGES} accent={ACCENT} />
      </section>
    </main>
  );
}
