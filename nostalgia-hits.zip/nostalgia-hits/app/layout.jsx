import "./globals.css";

export const metadata = {
  title: "Nostalgia Hits",
  description: "90s and 2000s cartoons, one theme song away.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="font-body text-lg bg-ink text-cream min-h-screen">
        <div className="crt-overlay" />
        {children}
      </body>
    </html>
  );
}
