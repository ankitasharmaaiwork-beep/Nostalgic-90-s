import Link from "next/link";

const SHOWS = [
  {
    href: "/pokemon",
    name: "Pokémon",
    era: "1997",
    tagline: "Gotta catch 'em all.",
    accent: "#f4a742",
  },
  {
    href: "/beyblade",
    name: "Beyblade",
    era: "2001",
    tagline: "Let it rip!",
    accent: "#e94560",
  },
];

export default function Home() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-16 text-center">
      <p className="mb-3 font-mono text-xs uppercase tracking-[0.3em] text-amber">
        Now Loading — Saturday Morning
      </p>
      <h1 className="font-display text-2xl leading-[1.9] text-cream">
        Nostalgia Hits
      </h1>
      <p className="mx-auto mt-4 max-w-md text-muted">
        Pick a show. See the art, hear the theme song.
      </p>

      <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2">
        {SHOWS.map((show) => (
          <Link
            key={show.href}
            href={show.href}
            className="group rounded-md border-2 border-line bg-panel p-8 text-left transition-transform hover:-translate-y-1"
            style={{ borderColor: show.accent + "55" }}
          >
            <span
              className="rounded-sm border px-2 py-1 font-mono text-[11px] uppercase tracking-widest"
              style={{ color: show.accent, borderColor: show.accent + "66" }}
            >
              {show.era}
            </span>
            <h2 className="mt-4 font-display text-sm leading-[1.7] text-cream">
              {show.name}
            </h2>
            <p className="mt-2 italic" style={{ color: show.accent }}>
              &ldquo;{show.tagline}&rdquo;
            </p>
          </Link>
        ))}
      </div>
    </main>
  );
}
