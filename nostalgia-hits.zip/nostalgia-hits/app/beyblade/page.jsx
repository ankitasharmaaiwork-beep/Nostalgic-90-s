import Link from "next/link";
import ThemeSongPlayer from "../../components/ThemeSongPlayer";
import ImageGrid from "../../components/ImageGrid";

const ACCENT = "#e94560";

// Poster image lives in /public/images/beyblade
const IMAGES = [
  { src: "/images/beyblade/beyblade-poster.jpg", alt: "Beyblade show poster" },
];

// Beyblade theme song
const VIDEO_ID = "Tjz5GvJY8xY";

export default function BeybladePage() {
  return (
    <main className="mx-auto max-w-5xl px-6 py-14">
      <Link href="/" className="font-mono text-xs uppercase tracking-widest text-faint hover:text-cream">
        ← Back
      </Link>

      <header className="mt-6 mb-10">
        <span
          className="rounded-sm border px-2 py-1 font-mono text-[11px] uppercase tracking-widest"
          style={{ color: ACCENT, borderColor: ACCENT + "66" }}
        >
          2001
        </span>
        <h1 className="mt-4 font-display text-xl leading-[1.8] text-cream">
          Beyblade
        </h1>
        <p className="mt-2 italic" style={{ color: ACCENT }}>
          &ldquo;Let it rip!&rdquo;
        </p>
        <p className="mt-3 max-w-xl text-muted">
          Spinning-top battles, bit-beasts, and a rivalry between Tyson and
          Kai that never really cooled down. The theme song plays
          automatically below — tap for sound.
        </p>
      </header>

      <section className="mb-12">
        <ThemeSongPlayer
          videoId={VIDEO_ID}
          title="Beyblade"
          accent={ACCENT}
          searchHint="Let's Beyblade theme song BEYBLADE English Official Channel"
        />
      </section>

      <section>
        <h2 className="mb-4 font-mono text-xs uppercase tracking-widest text-faint">
          Gallery
        </h2>
        <ImageGrid images={IMAGES} accent={ACCENT} />
      </section>
    </main>
  );
}
