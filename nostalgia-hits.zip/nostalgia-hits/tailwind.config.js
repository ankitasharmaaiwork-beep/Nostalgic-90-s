/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,jsx}",
    "./components/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: "#0f0f1e",
        panel: "#161629",
        line: "#2e2e4d",
        muted: "#9a9ab8",
        faint: "#5a5a7a",
        cream: "#f1faee",
        amber: "#f4a742",
        rose: "#e94560",
        teal: "#16c79a",
        violet: "#8e6bff",
      },
      fontFamily: {
        display: ["'Press Start 2P'", "monospace"],
        body: ["'VT323'", "monospace"],
      },
    },
  },
  plugins: [],
};
