# Nostalgia Hits

A two-page Next.js site: `/pokemon` and `/beyblade`, each with an image
gallery and an auto-playing official theme song.

## 1. Install and run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Already wired in

This copy already includes:

- Poster images at `public/images/pokemon/pokemon-poster.jpg` and
  `public/images/beyblade/beyblade-poster.jpg`, referenced from each page.
- Theme song video IDs pulled from the YouTube Music links provided
  (`KIKjB33zaSk` for Pokémon, `Tjz5GvJY8xY` for Beyblade).

**Note on the poster images:** these are official copyrighted show
artwork. They're fine for a personal/local project, but publishing them
on a public, promoted URL is a different story — the rights holders
could ask for a takedown. Swap in your own artwork if you plan to share
the site widely.

## 2. Add more theme songs / images (optional)

Browsers only allow autoplay if it starts **muted** — that's a browser
rule, not something this code can override. Each page starts the video
muted+autoplaying, with a "🔊 Play with sound" button that unmutes on
tap (a tap counts as user interaction, which unlocks audio).

Find each show's **official** YouTube upload, copy the video ID from the
URL (the part after `v=`), and paste it in:

- `app/pokemon/page.jsx` → `VIDEO_ID`
- `app/beyblade/page.jsx` → `VIDEO_ID`

For Beyblade, the original English theme "Let's Beyblade!" (performed by
Sick Kid ft. Lucas Rossi) is uploaded on the official
`BEYBLADE English - Official Channel` on YouTube.

## 3. Add images

Drop your own licensed or legally-sourced image files into:

- `public/images/pokemon/`
- `public/images/beyblade/`

Then list them in the `IMAGES` array at the top of the matching page
file, e.g.:

```js
const IMAGES = [
  { src: "/images/pokemon/pikachu.jpg", alt: "Pikachu" },
];
```

This starter doesn't ship with any character artwork baked in — Pokémon
and Beyblade art is copyrighted, so sourcing images (or using your own)
is left to you.

## 4. Deploy to Vercel

```bash
npx vercel
```

or push this folder to a GitHub repo and import it at vercel.com/new.
