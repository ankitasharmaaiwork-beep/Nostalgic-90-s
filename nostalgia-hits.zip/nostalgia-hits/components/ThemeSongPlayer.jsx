"use client";

import { useState } from "react";

/**
 * Plays a show's official YouTube theme song.
 *
 * Browsers block autoplay-with-sound until the visitor has interacted
 * with the page, so this starts muted+autoplaying (which browsers do
 * allow) and swaps to unmuted the moment the visitor taps "Play with
 * sound" — that tap counts as the interaction that unlocks audio.
 */
export default function ThemeSongPlayer({ videoId, title, accent, searchHint }) {
  const [unmuted, setUnmuted] = useState(false);

  if (!videoId) {
    return (
      <div
        className="flex h-full w-full flex-col items-center justify-center gap-3 rounded-sm border border-line bg-black/40 p-8 text-center"
        style={{ minHeight: 220 }}
      >
        <p className="text-sm text-faint">
          Add {title}'s official YouTube video ID to play the theme song here.
        </p>
        {searchHint && (
          <p className="text-xs text-faint/80">Try searching: &quot;{searchHint}&quot;</p>
        )}
      </div>
    );
  }

  const src = `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=${
    unmuted ? 0 : 1
  }&rel=0`;

  return (
    <div className="relative w-full overflow-hidden rounded-sm border border-line bg-black" style={{ aspectRatio: "16 / 9" }}>
      <iframe
        key={unmuted ? "unmuted" : "muted"}
        className="h-full w-full"
        src={src}
        title={`${title} theme song`}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
      {!unmuted && (
        <button
          onClick={() => setUnmuted(true)}
          className="absolute bottom-3 right-3 rounded-sm px-3 py-2 text-xs font-mono uppercase tracking-wider text-ink"
          style={{ backgroundColor: accent }}
        >
          🔊 Play with sound
        </button>
      )}
    </div>
  );
}
