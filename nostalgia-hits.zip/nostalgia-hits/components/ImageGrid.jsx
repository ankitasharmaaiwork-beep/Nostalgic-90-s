import Image from "next/image";

/**
 * Renders a responsive grid of images.
 *
 * `images` items look like: { src: "/images/pokemon/pikachu.jpg", alt: "Pikachu" }
 * Drop your own licensed/legally-sourced image files into the matching
 * folder under /public/images and list them here — this component
 * doesn't ship with any character art baked in.
 */
export default function ImageGrid({ images, accent }) {
  if (!images || images.length === 0) {
    return (
      <div className="rounded-sm border border-line bg-black/40 p-10 text-center">
        <p className="text-sm text-faint">
          No images yet — add files to the matching folder under{" "}
          <code className="text-muted">/public/images</code> and list them in
          this page's <code className="text-muted">images</code> array.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
      {images.map((img) => (
        <div
          key={img.src}
          className="group relative aspect-[2/3] overflow-hidden rounded-sm border-2 border-line bg-black"
          style={{ borderColor: accent + "33" }}
        >
          <Image
            src={img.src}
            alt={img.alt}
            fill
            sizes="(max-width: 768px) 90vw, 40vw"
            className="object-contain transition-transform duration-200 group-hover:scale-105"
          />
        </div>
      ))}
    </div>
  );
}
